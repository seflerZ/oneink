# OneInk - Uninstall Script
# Removes all registry entries and files (requires admin)
#
# Usage:
#   .\uninstall.ps1

param(
    [ValidateSet("x86", "x64", "arm64")]
    [string]$Platform = "x64"
)

. "$PSScriptRoot\config.ps1"

$ErrorActionPreference = 'SilentlyContinue'

$RegAsm = if ($Platform -eq "x86") { $Global:RegAsmX86 } elseif ($Platform -eq "arm64") { $Global:RegAsmARM64 } else { $Global:RegAsmX64 }
$dllPath = "$Global:InstallPath\OneInk.dll"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "OneInk Uninstall ($Platform)" -ForegroundColor Cyan
Write-Host "========================================"
Write-Host

if (Test-Path $dllPath) {
    Write-Host "Unregistering DLL..." -ForegroundColor Yellow
    & $RegAsm /unregister $dllPath 2>$null
}

foreach ($path in @(
    "HKLM:\SOFTWARE\Classes\CLSID\$Global:AddInCLSID",
    "HKLM:\SOFTWARE\Classes\AppID\$Global:AddInAppID",
    "HKCU:\SOFTWARE\Microsoft\Office\OneNote\AddIns\OneInk.AddIn",
    "HKCU:\SOFTWARE\Microsoft\Office\OneNote\AddInsData\OneInk.AddIn",
    "HKCU:\SOFTWARE\Classes\CLSID\$Global:AddInCLSID",
    "HKCU:\SOFTWARE\Classes\AppID\$Global:AddInAppID"
)) {
    if (Test-Path $path) { Remove-Item $path -Recurse -Force; Write-Host "Removed: $path" }
}

if (Test-Path $Global:InstallPath) {
    Write-Host "Removing $Global:InstallPath ..." -ForegroundColor Yellow
    Remove-Item $Global:InstallPath -Recurse -Force
    Write-Host "[OK] Files removed" -ForegroundColor Green
}

Write-Host
Write-Host "[OK] Uninstall complete!" -ForegroundColor Green
Write-Host "Restart OneNote to confirm." -ForegroundColor Cyan
