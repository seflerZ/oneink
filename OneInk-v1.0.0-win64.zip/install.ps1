# OneInk - Install Script (no build)
# Installs to Program Files and registers COM (requires admin)
#
# Usage:
#   .\install.ps1

param(
    [ValidateSet("x86", "x64", "arm64")]
    [string]$Platform = "x64"
)

. "$PSScriptRoot\config.ps1"

$ErrorActionPreference = "Stop"

$RegAsm = if ($Platform -eq "x86") { $Global:RegAsmX86 } elseif ($Platform -eq "arm64") { $Global:RegAsmARM64 } else { $Global:RegAsmX64 }
$OutputPath = $Global:InstallPath
$dllPath = "$OutputPath\OneInk.dll"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "OneInk Install ($Platform)" -ForegroundColor Cyan
Write-Host "========================================"
Write-Host

# 1. Copy to Program Files
Write-Host "[1/3] Copying to $OutputPath ..." -ForegroundColor Yellow
if (-not (Test-Path $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
}
$srcDir = Split-Path $PSCommandPath
robocopy $srcDir $OutputPath /MIR /R:3 /W:1 /XF "install.ps1","uninstall.ps1","config.ps1" | Out-Null
cmd /c "icacls `"$OutputPath`" /grant Everyone:(OI)(CI)RX /T" 2>$null
Write-Host "[OK]" -ForegroundColor Green

# 2. Register COM
Write-Host "[2/3] Registering COM AddIn..." -ForegroundColor Yellow

foreach ($path in @(
    "HKLM:\SOFTWARE\Classes\CLSID\$Global:AddInCLSID",
    "HKLM:\SOFTWARE\Classes\AppID\$Global:AddInAppID"
)) {
    if (Test-Path $path) { Remove-Item $path -Recurse -Force }
}

Set-Location $OutputPath
& $RegAsm /codebase /tlb $dllPath
if ($LASTEXITCODE -ne 0) { Write-Host "[WARNING] regasm exited with code $LASTEXITCODE" -ForegroundColor Yellow }

New-Item -Path "HKLM:\SOFTWARE\Classes\AppID\$Global:AddInAppID" -Force | Out-Null
Set-ItemProperty -Path "HKLM:\SOFTWARE\Classes\AppID\$Global:AddInAppID" -Name DllSurrogate -Value ""
Set-ItemProperty -Path "HKLM:\SOFTWARE\Classes\CLSID\$Global:AddInCLSID" -Name AppID -Value $Global:AddInAppID

$inprocPath = "HKLM:\SOFTWARE\Classes\CLSID\$Global:AddInCLSID\InprocServer32"
New-Item -Path $inprocPath -Force | Out-Null
Set-ItemProperty -Path $inprocPath -Name "(Default)" -Value "mscoree.dll"
Set-ItemProperty -Path $inprocPath -Name ThreadingModel -Value "Both"
Set-ItemProperty -Path $inprocPath -Name Class -Value "OneInk.AddIn"
Set-ItemProperty -Path $inprocPath -Name Assembly -Value "OneInk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null"
Set-ItemProperty -Path $inprocPath -Name RuntimeVersion -Value "v4.0.30319"
Set-ItemProperty -Path $inprocPath -Name CodeBase -Value "file:///$($OutputPath.Replace('\', '/'))/OneInk.dll"

$addinRegPath = "HKCU:\SOFTWARE\Microsoft\Office\OneNote\AddIns\OneInk.AddIn"
New-Item -Path $addinRegPath -Force | Out-Null
Set-ItemProperty -Path $addinRegPath -Name LoadBehavior -Value 3 -Type DWord
Set-ItemProperty -Path $addinRegPath -Name FriendlyName -Value "OneInk"
Set-ItemProperty -Path $addinRegPath -Name Description -Value "OneInk - OneNote Ink Operations"
Set-ItemProperty -Path $addinRegPath -Name CommandLineSafe -Value 1 -Type DWord
Write-Host "[OK]" -ForegroundColor Green

Write-Host "[3/3] Verification: $dllPath" -ForegroundColor Green
Write-Host "[OK] Installation complete!" -ForegroundColor Green
Write-Host
Write-Host "Restart OneNote to load the add-in." -ForegroundColor Cyan
